<div id="page-header">
		<!-- section background -->
		<div class="section-bg" style="background-image: url('{{ asset('front-assets/img/sliders.jpeg')}}');"></div>
		<!-- /section background -->

		<!-- page header content -->
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="header-content">
						<div class="col-md-8"> 
							<h1>Donate Now</h1>
								<ul class="breadcrumb">
									<li><a href="home">Home</a></li>
									<li><a href="#">Donate Now</a></li>
								</ul>
						</div>
					</div>

					<div class="navbar-right" style="padding-top:30px;">
						<a href="{{route('donations.create')}}" class="primary-button causes-donate" navbar-left>Donate Now  <i class="fa fa-arrow-right"></i></a>
					</div> 
				</div>
			</div>
		</div>
		<!-- /page header content -->
	</div>
	<!-- /Page Header -->