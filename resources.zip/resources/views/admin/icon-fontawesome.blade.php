<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta
      name="keywords"
      content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Matrix lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Matrix admin lite design, Matrix admin lite dashboard bootstrap 5 dashboard template"
    />
    <meta
      name="description"
      content="Matrix Admin Lite Free Version is powerful and clean admin dashboard template, inpired from Bootstrap Framework"
    />
    <meta name="robots" content="noindex,nofollow" />
    <title>Matrix Admin Lite Free Versions Template by WrapPixel</title>
    <!-- Favicon icon -->
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="../assets/images/favicon.png"
    />
    <!-- Custom CSS -->
    <link href="../dist/css/style.min.css" rel="stylesheet" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
      <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
      </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div
      id="main-wrapper"
      data-layout="vertical"
      data-navbarbg="skin5"
      data-sidebartype="full"
      data-sidebar-position="absolute"
      data-header-position="absolute"
      data-boxed-layout="full"
    >
      <!-- ============================================================== -->
      <!-- Topbar header - style you can find in pages.scss -->
      <!-- ============================================================== -->
      <header class="topbar" data-navbarbg="skin5">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
          <div class="navbar-header" data-logobg="skin5">
            <!-- ============================================================== -->
            <!-- Logo -->
            <!-- ============================================================== -->
            <a class="navbar-brand" href="index.html">
              <!-- Logo icon -->
              <b class="logo-icon ps-2">
                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                <!-- Dark Logo icon -->
                <img
                  src="../assets/images/logo-icon.png"
                  alt="homepage"
                  class="light-logo"
                  width="25"
                />
              </b>
              <!--End Logo icon -->
              <!-- Logo text -->
              <span class="logo-text ms-2">
                <!-- dark Logo text -->
                <img
                  src="../assets/images/logo-text.png"
                  alt="homepage"
                  class="light-logo"
                />
              </span>
              <!-- Logo icon -->
              <!-- <b class="logo-icon"> -->
              <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
              <!-- Dark Logo icon -->
              <!-- <img src="../assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->

              <!-- </b> -->
              <!--End Logo icon -->
            </a>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Toggle which is visible on mobile only -->
            <!-- ============================================================== -->
            <a
              class="nav-toggler waves-effect waves-light d-block d-md-none"
              href="javascript:void(0)"
              ><i class="ti-menu ti-close"></i
            ></a>
          </div>
          <!-- ============================================================== -->
          <!-- End Logo -->
          <!-- ============================================================== -->
          <div
            class="navbar-collapse collapse"
            id="navbarSupportedContent"
            data-navbarbg="skin5"
          >
            <!-- ============================================================== -->
            <!-- toggle and nav items -->
            <!-- ============================================================== -->
            <ul class="navbar-nav float-start me-auto">
              <li class="nav-item d-none d-lg-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i class="mdi mdi-menu font-24"></i
                ></a>
              </li>
              <!-- ============================================================== -->
              <!-- create new -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown">
                <a
                  class="nav-link dropdown-toggle"
                  href="#"
                  id="navbarDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <span class="d-none d-md-block"
                    >Create New <i class="fa fa-angle-down"></i
                  ></span>
                  <span class="d-block d-md-none"
                    ><i class="fa fa-plus"></i
                  ></span>
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="#">Action</a></li>
                  <li><a class="dropdown-item" href="#">Another action</a></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </li>
                </ul>
              </li>
              <!-- ============================================================== -->
              <!-- Search -->
              <!-- ============================================================== -->
              <li class="nav-item search-box">
                <a
                  class="nav-link waves-effect waves-dark"
                  href="javascript:void(0)"
                  ><i class="mdi mdi-magnify fs-4"></i
                ></a>
                <form class="app-search position-absolute">
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Search &amp; enter"
                  />
                  <a class="srh-btn"><i class="mdi mdi-window-close"></i></a>
                </form>
              </li>
            </ul>
            <!-- ============================================================== -->
            <!-- Right side toggle and nav items -->
            <!-- ============================================================== -->
            <ul class="navbar-nav float-end">
              <!-- ============================================================== -->
              <!-- Comment -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown">
                <a
                  class="nav-link dropdown-toggle"
                  href="#"
                  id="navbarDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <i class="mdi mdi-bell font-24"></i>
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="#">Action</a></li>
                  <li><a class="dropdown-item" href="#">Another action</a></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </li>
                </ul>
              </li>
              <!-- ============================================================== -->
              <!-- End Comment -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- Messages -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown">
                <a
                  class="nav-link dropdown-toggle waves-effect waves-dark"
                  href="#"
                  id="2"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <i class="font-24 mdi mdi-comment-processing"></i>
                </a>
                <ul
                  class="
                    dropdown-menu dropdown-menu-end
                    mailbox
                    animated
                    bounceInDown
                  "
                  aria-labelledby="2"
                >
                  <ul class="list-style-none">
                    <li>
                      <div class="">
                        <!-- Message -->
                        <a href="javascript:void(0)" class="link border-top">
                          <div class="d-flex no-block align-items-center p-10">
                            <span
                              class="
                                btn btn-success btn-circle
                                d-flex
                                align-items-center
                                justify-content-center
                              "
                              ><i class="mdi mdi-calendar text-white fs-4"></i
                            ></span>
                            <div class="ms-2">
                              <h5 class="mb-0">Event today</h5>
                              <span class="mail-desc"
                                >Just a reminder that event</span
                              >
                            </div>
                          </div>
                        </a>
                        <!-- Message -->
                        <a href="javascript:void(0)" class="link border-top">
                          <div class="d-flex no-block align-items-center p-10">
                            <span
                              class="
                                btn btn-info btn-circle
                                d-flex
                                align-items-center
                                justify-content-center
                              "
                              ><i class="mdi mdi-settings fs-4"></i
                            ></span>
                            <div class="ms-2">
                              <h5 class="mb-0">Settings</h5>
                              <span class="mail-desc"
                                >You can customize this template</span
                              >
                            </div>
                          </div>
                        </a>
                        <!-- Message -->
                        <a href="javascript:void(0)" class="link border-top">
                          <div class="d-flex no-block align-items-center p-10">
                            <span
                              class="
                                btn btn-primary btn-circle
                                d-flex
                                align-items-center
                                justify-content-center
                              "
                              ><i class="mdi mdi-account fs-4"></i
                            ></span>
                            <div class="ms-2">
                              <h5 class="mb-0">Pavan kumar</h5>
                              <span class="mail-desc"
                                >Just see the my admin!</span
                              >
                            </div>
                          </div>
                        </a>
                        <!-- Message -->
                        <a href="javascript:void(0)" class="link border-top">
                          <div class="d-flex no-block align-items-center p-10">
                            <span
                              class="
                                btn btn-danger btn-circle
                                d-flex
                                align-items-center
                                justify-content-center
                              "
                              ><i class="mdi mdi-link fs-4"></i
                            ></span>
                            <div class="ms-2">
                              <h5 class="mb-0">Luanch Admin</h5>
                              <span class="mail-desc"
                                >Just see the my new admin!</span
                              >
                            </div>
                          </div>
                        </a>
                      </div>
                    </li>
                  </ul>
                </ul>
              </li>
              <!-- ============================================================== -->
              <!-- End Messages -->
              <!-- ============================================================== -->

              <!-- ============================================================== -->
              <!-- User profile and search -->
              <!-- ============================================================== -->
              <li class="nav-item dropdown">
                <a
                  class="
                    nav-link
                    dropdown-toggle
                    text-muted
                    waves-effect waves-dark
                    pro-pic
                  "
                  href="#"
                  id="navbarDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <img
                    src="../assets/images/users/1.jpg"
                    alt="user"
                    class="rounded-circle"
                    width="31"
                  />
                </a>
                <ul
                  class="dropdown-menu dropdown-menu-end user-dd animated"
                  aria-labelledby="navbarDropdown"
                >
                  <a class="dropdown-item" href="javascript:void(0)"
                    ><i class="mdi mdi-account me-1 ms-1"></i> My Profile</a
                  >
                  <a class="dropdown-item" href="javascript:void(0)"
                    ><i class="mdi mdi-wallet me-1 ms-1"></i> My Balance</a
                  >
                  <a class="dropdown-item" href="javascript:void(0)"
                    ><i class="mdi mdi-email me-1 ms-1"></i> Inbox</a
                  >
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="javascript:void(0)"
                    ><i class="mdi mdi-settings me-1 ms-1"></i> Account
                    Setting</a
                  >
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="javascript:void(0)"
                    ><i class="fa fa-power-off me-1 ms-1"></i> Logout</a
                  >
                  <div class="dropdown-divider"></div>
                  <div class="ps-4 p-10">
                    <a
                      href="javascript:void(0)"
                      class="btn btn-sm btn-success btn-rounded text-white"
                      >View Profile</a
                    >
                  </div>
                </ul>
              </li>
              <!-- ============================================================== -->
              <!-- User profile and search -->
              <!-- ============================================================== -->
            </ul>
          </div>
        </nav>
      </header>
      <!-- ============================================================== -->
      <!-- End Topbar header -->
      <!-- ============================================================== -->
      <!-- ============================================================== -->
      <!-- Left Sidebar - style you can find in sidebar.scss  -->
      <!-- ============================================================== -->
      <aside class="left-sidebar" data-sidebarbg="skin5">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
          <!-- Sidebar navigation-->
          <nav class="sidebar-nav">
            <ul id="sidebarnav" class="pt-4">
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('/')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-view-dashboard"></i
                  ><span class="hide-menu">Dashboard</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('charts')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-chart-bar"></i
                  ><span class="hide-menu">Charts</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('widgets')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-chart-bubble"></i
                  ><span class="hide-menu">Widgets</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('tables')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-border-inside"></i
                  ><span class="hide-menu">Tables</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('grid')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-blur-linear"></i
                  ><span class="hide-menu">Full Width</span></a
                >
              </li>
              
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i class="mdi mdi-receipt"></i
                  ><span class="hide-menu">Forms </span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                    <li class="sidebar-item">
                        <a href="{{url('class-form')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">Class Form </span></a
                        >
                      </li>
                      <li class="sidebar-item">
                        <a href="{{url('section')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">Section </span></a
                        >
                      </li>
                      <li class="sidebar-item">
                        <a href="{{url('fee_category')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">Fee Category </span></a
                        >
                      </li>
                      <li class="sidebar-item">
                        <a href="{{url('fee_types')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">Fee Types </span></a
                        >
                      </li>
                      <li class="sidebar-item">
                        <a href="{{url('fee_master')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">Fee Master </span></a
                        >
                      </li>
                      <li class="sidebar-item">
                        <a href="{{url('admission_type')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">Admission Type </span></a
                        >
                      </li>
                      <li class="sidebar-item">
                        <a href="{{url('new_admission')}}" class="sidebar-link"
                          ><i class="mdi mdi-note-outline"></i
                          ><span class="hide-menu">New Admission </span></a
                        >
                      </li>
                  <li class="sidebar-item">
                    <a href="{{url('form-wizard')}}" class="sidebar-link"
                      ><i class="mdi mdi-note-plus"></i
                      ><span class="hide-menu"> Form Wizard </span></a
                    >
                  </li>
                  
                  
                </ul>
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('buttons')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-relative-scale"></i
                  ><span class="hide-menu">Buttons</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i class="mdi mdi-face"></i
                  ><span class="hide-menu">Icons </span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  <li class="sidebar-item">
                    <a href="{{url('material-icons')}}" class="sidebar-link"
                      ><i class="mdi mdi-emoticon"></i
                      ><span class="hide-menu"> Material Icons </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('fontawesome-icons')}}" class="sidebar-link"
                      ><i class="mdi mdi-emoticon-cool"></i
                      ><span class="hide-menu"> Font Awesome Icons </span></a
                    >
                  </li>
                </ul>
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="{{url('pages-elements')}}"
                  aria-expanded="false"
                  ><i class="mdi mdi-pencil"></i
                  ><span class="hide-menu">Elements</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i class="mdi mdi-move-resize-variant"></i
                  ><span class="hide-menu">Addons </span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  <li class="sidebar-item">
                    <a href="{{url('index-page2')}}" class="sidebar-link"
                      ><i class="mdi mdi-view-dashboard"></i
                      ><span class="hide-menu"> Dashboard-2 </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('pages-gallery')}}" class="sidebar-link"
                      ><i class="mdi mdi-multiplication-box"></i
                      ><span class="hide-menu"> Gallery </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('calendar')}}" class="sidebar-link"
                      ><i class="mdi mdi-calendar-check"></i
                      ><span class="hide-menu"> Calendar </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('pages-invoice')}}" class="sidebar-link"
                      ><i class="mdi mdi-bulletin-board"></i
                      ><span class="hide-menu"> Invoice </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('pages-chat')}}" class="sidebar-link"
                      ><i class="mdi mdi-message-outline"></i
                      ><span class="hide-menu"> Chat Option </span></a
                    >
                  </li>
                </ul>
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i class="mdi mdi-account-key"></i
                  ><span class="hide-menu">Authentication </span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  <li class="sidebar-item">
                    <a href="{{url('auth-login')}}" class="sidebar-link"
                      ><i class="mdi mdi-all-inclusive"></i
                      ><span class="hide-menu"> Login </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('auth-register')}}" class="sidebar-link"
                      ><i class="mdi mdi-all-inclusive"></i
                      ><span class="hide-menu"> Register </span></a
                    >
                  </li>
                </ul>
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i class="mdi mdi-alert"></i
                  ><span class="hide-menu">Errors </span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  <li class="sidebar-item">
                    <a href="{{url('error-403')}}" class="sidebar-link"
                      ><i class="mdi mdi-alert-octagon"></i
                      ><span class="hide-menu"> Error 403 </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('error-404')}}" class="sidebar-link"
                      ><i class="mdi mdi-alert-octagon"></i
                      ><span class="hide-menu"> Error 404 </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('error-405')}}" class="sidebar-link"
                      ><i class="mdi mdi-alert-octagon"></i
                      ><span class="hide-menu"> Error 405 </span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a href="{{url('error-500')}}" class="sidebar-link"
                      ><i class="mdi mdi-alert-octagon"></i
                      ><span class="hide-menu"> Error 500 </span></a
                    >
                  </li>
              
            </ul>
          </nav>
          <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
      </aside>
      <!-- ============================================================== -->
      <!-- End Left Sidebar - style you can find in sidebar.scss  -->
      <!-- ============================================================== -->
      <!-- ============================================================== -->
      <!-- Page wrapper  -->
      <!-- ============================================================== -->
      <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb">
          <div class="row">
            <div class="col-12 d-flex no-block align-items-center">
              <h4 class="page-title">Fontawesome Icons</h4>
              <div class="ms-auto text-end">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                      Library
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
          <!-- ============================================================== -->
          <!-- Start Page Content -->
          <!-- ============================================================== -->
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Solid Icons</h4>
                  <h6 class="card-subtitle">
                    use the icon by just put class
                    <code>fas fa-address-book</code> in i tag
                  </h6>
                  <section>
                    <div class="icon-list-demo row">
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-address-book"></i> fas fa-address-book
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-address-card"></i> fas fa-address-card
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-adjust"></i> fas fa-adjust
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-align-center"></i> fas fa-align-center
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-align-justify"></i> fas
                        fa-align-justify
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-align-left"></i> fas fa-align-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-align-right"></i> fas fa-align-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-allergies"></i> fas fa-allergies
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ambulance"></i> fas fa-ambulance
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i
                          class="fas fa-american-sign-language-interpreting"
                        ></i>
                        fas fa-american-sign-language-interpreting
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-anchor"></i> fas fa-anchor
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-double-down"></i> fas
                        fa-angle-double-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-double-left"></i> fas
                        fa-angle-double-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-double-right"></i> fas
                        fa-angle-double-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-double-up"></i> fas
                        fa-angle-double-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-down"></i> fas fa-angle-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-left"></i> fas fa-angle-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-right"></i> fas fa-angle-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-angle-up"></i> fas fa-angle-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-archive"></i> fas fa-archive
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-alt-circle-down"></i> fas
                        fa-arrow-alt-circle-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-alt-circle-left"></i> fas
                        fa-arrow-alt-circle-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-alt-circle-right"></i> fas
                        fa-arrow-alt-circle-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-alt-circle-up"></i> fas
                        fa-arrow-alt-circle-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-circle-down"></i> fas
                        fa-arrow-circle-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-circle-left"></i> fas
                        fa-arrow-circle-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-circle-right"></i> fas
                        fa-arrow-circle-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-circle-up"></i> fas
                        fa-arrow-circle-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-down"></i> fas fa-arrow-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-left"></i> fas fa-arrow-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-right"></i> fas fa-arrow-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrow-up"></i> fas fa-arrow-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrows-alt"></i> fas fa-arrows-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrows-alt-h"></i> fas fa-arrows-alt-h
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-arrows-alt-v"></i> fas fa-arrows-alt-v
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-assistive-listening-systems"></i> fas
                        fa-assistive-listening-systems
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-asterisk"></i> fas fa-asterisk
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-at"></i> fas fa-at
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-audio-description"></i> fas
                        fa-audio-tion
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-backward"></i> fas fa-backward
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-balance-scale"></i> fas
                        fa-balance-scale
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ban"></i> fas fa-ban
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-band-aid"></i> fas fa-band-aid
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-barcode"></i> fas fa-barcode
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bars"></i> fas fa-bars
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-baseball-ball"></i> fas
                        fa-baseball-ball
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-basketball-ball"></i> fas fa-basketba
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bath"></i> fas fa-bath
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-battery-empty"></i> fas
                        fa-battery-empty
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-battery-full"></i> fas fa-battery-full
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-battery-half"></i> fas fa-battery-half
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-battery-quarter"></i> fas
                        fa-battery-quarter
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-battery-three-quarters"></i> fas
                        fa-battery-three-quarters
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bed"></i> fas fa-bed
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-beer"></i> fas fa-beer
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bell"></i> fas fa-bell
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bell-slash"></i> fas fa-bell-slash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bicycle"></i> fas fa-bicycle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-binoculars"></i> fas fa-binoculars
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-birthday-cake"></i> fas
                        fa-birthday-cake
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-blind"></i> fas fa-blind
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bold"></i> fas fa-bold
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bolt"></i> fas fa-bolt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bomb"></i> fas fa-bomb
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-book"></i> fas fa-book
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bookmark"></i> fas fa-bookmark
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bowling-ball"></i> fas fa-bowling-ball
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-box"></i> fas fa-box
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-box-open"></i> fas fa-box-open
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-boxes"></i> fas fa-boxes
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-braille"></i> fas fa-braille
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-briefcase"></i> fas fa-briefcase
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-briefcase-medical"></i> fas
                        fa-briefcical
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bug"></i> fas fa-bug
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-building"></i> fas fa-building
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bullhorn"></i> fas fa-bullhorn
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bullseye"></i> fas fa-bullseye
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-burn"></i> fas fa-burn
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-bus"></i> fas fa-bus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calculator"></i> fas fa-calculator
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calendar"></i> fas fa-calendar
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calendar-alt"></i> fas fa-calendar-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calendar-check"></i> fas
                        fa-calendar-check
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calendar-minus"></i> fas
                        fa-calendar-minus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calendar-plus"></i> fas
                        fa-calendar-plus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-calendar-times"></i> fas
                        fa-calendar-times
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-camera"></i> fas fa-camera
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-camera-retro"></i> fas fa-camera-retro
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-capsules"></i> fas fa-capsules
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-car"></i> fas fa-car
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-down"></i> fas fa-caret-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-left"></i> fas fa-caret-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-right"></i> fas fa-caret-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-square-down"></i> fas
                        fa-caret-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-square-left"></i> fas
                        fa-caret-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-square-right"></i> fas
                        fa-caret-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-square-up"></i> fas fa-caret-sq
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-caret-up"></i> fas fa-caret-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cart-arrow-down"></i> fas fa-cart-arr
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cart-plus"></i> fas fa-cart-plus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-certificate"></i> fas fa-certificate
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chart-area"></i> fas fa-chart-area
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chart-bar"></i> fas fa-chart-bar
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chart-line"></i> fas fa-chart-line
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chart-pie"></i> fas fa-chart-pie
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-check"></i> fas fa-check
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-check-circle"></i> fas fa-check-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-check-square"></i> fas fa-check-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess"></i> fas fa-chess
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-bishop"></i> fas fa-chess-bishop
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-board"></i> fas fa-chess-board
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-king"></i> fas fa-chess-king
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-knight"></i> fas fa-chess-knight
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-pawn"></i> fas fa-chess-pawn
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-queen"></i> fas fa-chess-queen
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chess-rook"></i> fas fa-chess-rook
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-circle-down"></i> fas
                        fa-chevron-circle-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-circle-left"></i> fas
                        fa-chevron-circle-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-circle-right"></i> fas
                        fa-chevron-circle-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-circle-up"></i> fas
                        fa-chevroe-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-down"></i> fas fa-chevron-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-left"></i> fas fa-chevron-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-right"></i> fas
                        fa-chevron-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-chevron-up"></i> fas fa-chevron-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-child"></i> fas fa-child
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-circle"></i> fas fa-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-circle-notch"></i> fas fa-circle-notch
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-clipboard"></i> fas fa-clipboard
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-clipboard-check"></i> fas
                        fa-clipboard-check
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-clipboard-list"></i> fas
                        fa-clipboard-list
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-clock"></i> fas fa-clock
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-clone"></i> fas fa-clone
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-closed-captioning"></i> fas
                        fa-closedning
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cloud"></i> fas fa-cloud
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cloud-download-alt"></i> fas
                        fa-cloudad-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cloud-upload-alt"></i> fas fa-cloud-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-code"></i> fas fa-code
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-code-branch"></i> fas fa-code-branch
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-coffee"></i> fas fa-coffee
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cog"></i> fas fa-cog
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cogs"></i> fas fa-cogs
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-columns"></i> fas fa-columns
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-comment"></i> fas fa-comment
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-comment-alt"></i> fas fa-comment-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-comment-dots"></i> fas fa-comment-dots
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-comment-slash"></i> fas
                        fa-comment-slash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-comments"></i> fas fa-comments
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-compass"></i> fas fa-compass
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-compress"></i> fas fa-compress
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-copy"></i> fas fa-copy
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-copyright"></i> fas fa-copyright
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-couch"></i> fas fa-couch
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-credit-card"></i> fas fa-credit-card
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-crop"></i> fas fa-crop
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-crosshairs"></i> fas fa-crosshairs
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cube"></i> fas fa-cube
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cubes"></i> fas fa-cubes
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-cut"></i> fas fa-cut
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-database"></i> fas fa-database
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-deaf"></i> fas fa-deaf
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-desktop"></i> fas fa-desktop
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-diagnoses"></i> fas fa-diagnoses
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-dna"></i> fas fa-dna
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-dollar-sign"></i> fas fa-dollar-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-dolly"></i> fas fa-dolly
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-dolly-flatbed"></i> fas
                        fa-dolly-flatbed
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-donate"></i> fas fa-donate
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-dot-circle"></i> fas fa-dot-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-dove"></i> fas fa-dove
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-download"></i> fas fa-download
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-edit"></i> fas fa-edit
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-eject"></i> fas fa-eject
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ellipsis-h"></i> fas fa-ellipsis-h
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ellipsis-v"></i> fas fa-ellipsis-v
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-envelope"></i> fas fa-envelope
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-envelope-open"></i> fas
                        fa-envelope-open
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-envelope-square"></i> fas
                        fa-envelope-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-eraser"></i> fas fa-eraser
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-euro-sign"></i> fas fa-euro-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-exchange-alt"></i> fas fa-exchange-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-exclamation"></i> fas fa-exclamation
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-exclamation-circle"></i> fas
                        fa-exclamation-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-exclamation-triangle"></i> fas
                        fa-exclamation-triangle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-expand"></i> fas fa-expand
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-expand-arrows-alt"></i> fas
                        fa-expand-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-external-link-alt"></i> fas
                        fa-external-link-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-external-link-square-alt"></i> fas
                        fa-external-link-square-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-eye"></i> fas fa-eye
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-eye-dropper"></i> fas fa-eye-dropper
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-eye-slash"></i> fas fa-eye-slash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-fast-backward"></i> fas
                        fa-fast-backward
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-fast-forward"></i> fas fa-fast-forward
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-fax"></i> fas fa-fax
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-female"></i> fas fa-female
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-fighter-jet"></i> fas fa-fighter-jet
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file"></i> fas fa-file
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-alt"></i> fas fa-file-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-archive"></i> fas fa-file-archive
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-audio"></i> fas fa-file-audio
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-code"></i> fas fa-file-code
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-excel"></i> fas fa-file-excel
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-image"></i> fas fa-file-image
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-medical"></i> fas fa-file-medical
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-medical-alt"></i> fas
                        fa-file-medical-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-pdf"></i> fas fa-file-pdf
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-powerpoint"></i> fas fa-file-pow
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-video"></i> fas fa-file-video
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-file-word"></i> fas fa-file-word
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-film"></i> fas fa-film
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-filter"></i> fas fa-filter
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-fire"></i> fas fa-fire
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-fire-extinguisher"></i> fas
                        fa-fire-extinguisher
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-first-aid"></i> fas fa-first-aid
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-flag"></i> fas fa-flag
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-flag-checkered"></i> fas
                        fa-flag-checkered
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-flask"></i> fas fa-flask
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-folder"></i> fas fa-folder
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-folder-open"></i> fas fa-folder-open
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-font"></i> fas fa-font
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-football-ball"></i> fas
                        fa-football-ball
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-forward"></i> fas fa-forward
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-frown"></i> fas fa-frown
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-futbol"></i> fas fa-futbol
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-gamepad"></i> fas fa-gamepad
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-gavel"></i> fas fa-gavel
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-gem"></i> fas fa-gem
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-genderless"></i> fas fa-genderless
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-gift"></i> fas fa-gift
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-glass-martini"></i> fas
                        fa-glass-martini
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-globe"></i> fas fa-globe
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-golf-ball"></i> fas fa-golf-ball
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-graduation-cap"></i> fas
                        fa-graduation-cap
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-h-square"></i> fas fa-h-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-holding"></i> fas fa-hand-holding
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-holding-heart"></i> fas
                        fa-hand-holding-heart
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-holding-usd"></i> fas
                        fa-hand-holding-usd
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-lizard"></i> fas fa-hand-lizard
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-paper"></i> fas fa-hand-paper
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-peace"></i> fas fa-hand-peace
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-point-down"></i> fas
                        fa-hand-point-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-point-left"></i> fas
                        fa-hand-point-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-point-right"></i> fas
                        fa-hand-point-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-point-up"></i> fas
                        fa-hand-point-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-pointer"></i> fas fa-hand-pointer
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-rock"></i> fas fa-hand-rock
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-scissors"></i> fas
                        fa-hand-scissors
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hand-spock"></i> fas fa-hand-spock
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hands"></i> fas fa-hands
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hands-helping"></i> fas
                        fa-hands-helping
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-handshake"></i> fas fa-handshake
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hashtag"></i> fas fa-hashtag
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hdd"></i> fas fa-hdd
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-heading"></i> fas fa-heading
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-headphones"></i> fas fa-headphones
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-heart"></i> fas fa-heart
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-heartbeat"></i> fas fa-heartbeat
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-history"></i> fas fa-history
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hockey-puck"></i> fas fa-hockey-puck
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-home"></i> fas fa-home
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hospital"></i> fas fa-hospital
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hospital-alt"></i> fas fa-hospital-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hospital-symbol"></i> fas fa-hospital
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hourglass"></i> fas fa-hourglass
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hourglass-end"></i> fas
                        fa-hourglass-end
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hourglass-half"></i> fas
                        fa-hourglass-half
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-hourglass-start"></i> fas
                        fa-hourglass-start
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-i-cursor"></i> fas fa-i-cursor
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-id-badge"></i> fas fa-id-badge
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-id-card"></i> fas fa-id-card
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-id-card-alt"></i> fas fa-id-card-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-image"></i> fas fa-image
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-images"></i> fas fa-images
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-inbox"></i> fas fa-inbox
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-indent"></i> fas fa-indent
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-industry"></i> fas fa-industry
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-info"></i> fas fa-info
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-info-circle"></i> fas fa-info-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-italic"></i> fas fa-italic
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-key"></i> fas fa-key
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-keyboard"></i> fas fa-keyboard
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-language"></i> fas fa-language
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-laptop"></i> fas fa-laptop
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-leaf"></i> fas fa-leaf
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-lemon"></i> fas fa-lemon
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-level-down-alt"></i> fas
                        fa-level-down-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-level-up-alt"></i> fas fa-level-up-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-life-ring"></i> fas fa-life-ring
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-lightbulb"></i> fas fa-lightbulb
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-link"></i> fas fa-link
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-lira-sign"></i> fas fa-lira-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-list"></i> fas fa-list
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-list-alt"></i> fas fa-list-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-list-ol"></i> fas fa-list-ol
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-list-ul"></i> fas fa-list-ul
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-location-arrow"></i> fas
                        fa-location-arrow
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-lock"></i> fas fa-lock
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-lock-open"></i> fas fa-lock-open
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-long-arrow-alt-down"></i> fas
                        fa-long-arrow-alt-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-long-arrow-alt-left"></i> fas
                        fa-long-arrow-alt-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-long-arrow-alt-right"></i> fas
                        fa-long-arrow-alt-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-long-arrow-alt-up"></i> fas
                        fa-long-arrow-alt-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-low-vision"></i> fas fa-low-vision
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-magic"></i> fas fa-magic
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-magnet"></i> fas fa-magnet
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-male"></i> fas fa-male
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-map"></i> fas fa-map
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-map-marker"></i> fas fa-map-marker
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-map-marker-alt"></i> fas
                        fa-map-marker-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-map-pin"></i> fas fa-map-pin
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-map-signs"></i> fas fa-map-signs
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mars"></i> fas fa-mars
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mars-double"></i> fas fa-mars-double
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mars-stroke"></i> fas fa-mars-stroke
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mars-stroke-h"></i> fas
                        fa-mars-stroke-h
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mars-stroke-v"></i> fas
                        fa-mars-stroke-v
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-medkit"></i> fas fa-medkit
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-meh"></i> fas fa-meh
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mercury"></i> fas fa-mercury
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-microchip"></i> fas fa-microchip
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-microphone"></i> fas fa-microphone
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-microphone-slash"></i> fas
                        fa-microphone-slash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-minus"></i> fas fa-minus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-minus-circle"></i> fas fa-minus-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-minus-square"></i> fas fa-minus-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mobile"></i> fas fa-mobile
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mobile-alt"></i> fas fa-mobile-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-money-bill-alt"></i> fas money-bill-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-moon"></i> fas fa-moon
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-motorcycle"></i> fas fa-motorcycle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-mouse-pointer"></i> fas
                        fa-mouse-pointer
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-music"></i> fas fa-music
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-neuter"></i> fas fa-neuter
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-newspaper"></i> fas fa-newspaper
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-notes-medical"></i> fas
                        fa-notes-medical
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-object-group"></i> fas fa-object-group
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-object-ungroup"></i> fas
                        fa-object-ungroup
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-outdent"></i> fas fa-outdent
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-paint-brush"></i> fas fa-paint-brush
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pallet"></i> fas fa-pallet
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-paper-plane"></i> fas fa-paper-plane
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-paperclip"></i> fas fa-paperclip
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-parachute-box"></i> fas
                        fa-parachute-box
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-paragraph"></i> fas fa-paragraph
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-paste"></i> fas fa-paste
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pause"></i> fas fa-pause
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pause-circle"></i> fas pause-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-paw"></i> fas fa-fa-paw
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pen-square"></i> fas fa-pen-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pencil-alt"></i> fas fa-pencil-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-people-carry"></i> fas fa-people-carry
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-percent"></i> fas fa-percent
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-phone"></i> fas fa-phone
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-phone-slash"></i> fas fa-phone-slash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-phone-square"></i> fas fa-phone-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-phone-volume"></i> fas fa-phone-volume
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-piggy-bank"></i> fas fa-piggy-bank
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pills"></i> fas fa-pills
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-plane"></i> fas fa-plane
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-play"></i> fas fa-play
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-play-circle"></i> fas fa-play-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-plug"></i> fas fa-plug
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-plus"></i> fas fa-plus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-plus-circle"></i> fas fa-plus-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-plus-square"></i> fas fa-plus-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-podcast"></i> fas fa-podcast
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-poo"></i> fas fa-poo
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-pound-sign"></i> fas fa-pound-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-power-off"></i> fas fa-power-off
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-prescription-bottle"></i> fas
                        fa-prescription-bottle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-prescription-bottle-alt"></i> fas
                        fa-prescription-bottle-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-print"></i> fas fa-print
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-procedures"></i> fas fa-procedures
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-puzzle-piece"></i> fas fa-puzzle-piece
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-qrcode"></i> fas fa-qrcode
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-question"></i> fas fa-question
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-question-circle"></i> fas fa-question
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-quidditch"></i> fas fa-quidditch
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-quote-left"></i> fas fa-quote-left
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-quote-right"></i> fas fa-quote-right
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-random"></i> fas fa-random
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-recycle"></i> fas fa-recycle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-redo"></i> fas fa-redo
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-redo-alt"></i> fas fa-redo-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-registered"></i> fas fa-registered
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-reply"></i> fas fa-reply
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-reply-all"></i> fas fa-reply-all
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-retweet"></i> fas fa-retweet
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ribbon"></i> fas fa-ribbon
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-road"></i> fas fa-road
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-rocket"></i> fas fa-rocket
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-rss"></i> fas fa-rss
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-rss-square"></i> fas fa-rss-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ruble-sign"></i> fas fa-ruble-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-rupee-sign"></i> fas fa-rupee-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-save"></i> fas fa-save
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-search"></i> fas fa-search
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-search-minus"></i> fas fa-search-minus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-search-plus"></i> fas fa-search-plus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-seedling"></i> fas fa-seedling
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-server"></i> fas fa-server
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-share"></i> fas fa-share
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-share-alt"></i> fas fa-share-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-share-alt-square"></i> fas
                        fa-share-alt-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-share-square"></i> fas fa-share-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shekel-sign"></i> fas fa-shekel-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shield-alt"></i> fas fa-shield-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ship"></i> fas fa-ship
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shipping-fast"></i> fas
                        fa-shipping-fast
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shopping-bag"></i> fas fa-shopping-bag
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shopping-basket"></i> fas
                        fa-shopping-basket
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shopping-cart"></i> fas
                        fa-shopping-cart
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-shower"></i> fas fa-shower
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sign"></i> fas fa-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sign-in-alt"></i> fas fa-sign-in-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sign-language"></i> fas
                        fa-sign-language
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sign-out-alt"></i> fas fa-sign-out-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-signal"></i> fas fa-signal
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sitemap"></i> fas fa-sitemap
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sliders-h"></i> fas fa-sliders-h
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-smile"></i> fas fa-smile
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-smoking"></i> fas fa-smoking
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-snowflake"></i> fas fa-snowflake
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort"></i> fas fa-sort
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-alpha-down"></i> fas fa-alpha-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-alpha-up"></i> fas
                        fa-sort-alpha-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-amount-down"></i> fas
                        fa-sort-amount-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-amount-up"></i> fas
                        fa-sort-amount-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-down"></i> fas fa-sort-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-numeric-down"></i> fas
                        fa-sort-numeric-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-numeric-up"></i> fas
                        fa-sort-numeric-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sort-up"></i> fas fa-sort-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-space-shuttle"></i> fas
                        fa-space-shuttle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-spinner"></i> fas fa-spinner
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-square"></i> fas fa-square
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-square-full"></i> fas fa-square-full
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-star"></i> fas fa-star
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-star-half"></i> fas fa-star-half
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-step-backward"></i> fas
                        fa-step-backward
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-step-forward"></i> fas fa-step-forward
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-stethoscope"></i> fas fa-stethoscope
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sticky-note"></i> fas fa-sticky-note
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-stop"></i> fas fa-stop
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-stop-circle"></i> fas fa-stop-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-stopwatch"></i> fas fa-stopwatch
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-street-view"></i> fas fa-street-view
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-strikethrough"></i> fas
                        fa-strikethrough
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-subscript"></i> fas fa-subscript
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-subway"></i> fas fa-subway
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-suitcase"></i> fas fa-suitcase
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sun"></i> fas fa-sun
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-superscript"></i> fas fa-superscript
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sync"></i> fas fa-sync
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-sync-alt"></i> fas fa-sync-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-syringe"></i> fas fa-syringe
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-table"></i> fas fa-table
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-table-tennis"></i> fas fa-table-tennis
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tablet"></i> fas fa-tablet
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tablet-alt"></i> fas fa-tablet-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tablets"></i> fas fa-tablets
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tachometer-alt"></i> fas
                        fa-tachometer-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tag"></i> fas fa-tag
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tags"></i> fas fa-tags
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tape"></i> fas fa-tape
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tasks"></i> fas fa-tasks
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-taxi"></i> fas fa-taxi
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-terminal"></i> fas fa-terminal
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-text-height"></i> fas fa-text-height
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-text-width"></i> fas fa-text-width
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-th"></i> fas fa-th
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-th-large"></i> fas fa-th-large
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-th-list"></i> fas fa-th-list
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thermometer"></i> fas fa-thermometer
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thermometer-empty"></i> fas
                        fa-thermometer-empty
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thermometer-full"></i> fas
                        fa-thermometer-full
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thermometer-half"></i> fas
                        fa-thermometer-half
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thermometer-quarter"></i> fas
                        fa-thermometer-quarter
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thermometer-three-quarters"></i> fas
                        fa-thermometer-three-quarters
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thumbs-down"></i> fas fa-thumbs-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thumbs-up"></i> fas fa-thumbs-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-thumbtack"></i> fas fa-thumbtack
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-ticket-alt"></i> fas fa-ticket-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-times"></i> fas fa-times
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-times-circle"></i> fas fa-times-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tint"></i> fas fa-tint
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-toggle-off"></i> fas fa-toggle-off
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-toggle-on"></i> fas fa-toggle-on
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-trademark"></i> fas fa-trademark
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-train"></i> fas fa-train
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-transgender"></i> fas fa-transgender
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-transgender-alt"></i> fas fa-transgen
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-trash"></i> fas fa-trash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-trash-alt"></i> fas fa-trash-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tree"></i> fas fa-tree
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-trophy"></i> fas fa-trophy
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-truck"></i> fas fa-truck
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-truck-loading"></i> fas
                        fa-truck-loading
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-truck-moving"></i> fas fa-truck-moving
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tty"></i> fas fa-tty
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-tv"></i> fas fa-tv
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-umbrella"></i> fas fa-umbrella
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-underline"></i> fas fa-underline
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-undo"></i> fas fa-undo
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-undo-alt"></i> fas fa-undo-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-universal-access"></i> fas
                        fa-universal-access
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-university"></i> fas fa-university
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-unlink"></i> fas fa-unlink
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-unlock"></i> fas fa-unlock
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-unlock-alt"></i> fas fa-unlock-alt
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-upload"></i> fas fa-upload
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-user"></i> fas fa-user
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-user-circle"></i> fas fa-user-circle
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-user-md"></i> fas fa-user-md
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-user-plus"></i> fas fa-user-plus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-user-secret"></i> fas fa-user-secret
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-user-times"></i> fas fa-user-times
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-users"></i> fas fa-users
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-utensil-spoon"></i> fas
                        fa-utensil-spoon
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-utensils"></i> fas fa-utensils
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-venus"></i> fas fa-venus
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-venus-double"></i> fas fa-venus-double
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-venus-mars"></i> fas fa-venus-mars
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-vial"></i> fas fa-vial
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-vials"></i> fas fa-vials
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-video"></i> fas fa-video
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-video-slash"></i> fas fa-video-slash
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-volleyball-ball"></i> fas fa-volleyba
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-volume-down"></i> fas fa-volume-down
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-volume-off"></i> fas fa-volume-off
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-volume-up"></i> fas fa-volume-up
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-warehouse"></i> fas fa-warehouse
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-weight"></i> fas fa-weight
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-wheelchair"></i> fas fa-wheelchair
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-wifi"></i> fas fa-wifi
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-window-close"></i> fas fa-window-close
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-window-maximize"></i> fas
                        fa-window-maximize
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-window-minimize"></i> fas
                        fa-window-minimize
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-window-restore"></i> fas
                        fa-window-restore
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-wine-glass"></i> fas fa-wine-glass
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-won-sign"></i> fas fa-won-sign
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-wrench"></i> fas fa-wrench
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-x-ray"></i> fas fa-x-ray
                      </div>
                      <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                        <i class="fas fa-yen-sign"></i> fas fa-yen-sign
                      </div>
                    </div>
                  </section>
                </div>
              </div>
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Regular Icons</h4>
                  <h6 class="card-subtitle">
                    use the icon by just put class
                    <code>far fa-address-card</code> in i tag
                  </h6>
                  <div class="icon-list-demo row">
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-address-book"></i
                      ><span> far fa-address-book</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-address-card"></i
                      ><span> far fa-address-card</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-arrow-alt-circle-down"></i
                      ><span> far fa-arrow-alt-circle-down</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-arrow-alt-circle-left"></i
                      ><span> far fa-arrow-alt-circle-left</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-arrow-alt-circle-right"></i
                      ><span> far fa-arrow-alt-circle-right</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-arrow-alt-circle-up"></i
                      ><span> far fa-arrow-alt-circle-up</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-bell"></i><span> far fa-bell</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-bell-slash"></i
                      ><span> far fa-bell-slash</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-bookmark"></i
                      ><span> far fa-bookmark</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-building"></i
                      ><span> far fa-building</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-calendar"></i
                      ><span> far fa-calendar</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-calendar-alt"></i
                      ><span> far fa-calendar-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-calendar-check"></i
                      ><span> far fa-calendar-check</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-calendar-minus"></i
                      ><span> far fa-calendar-minus</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-calendar-plus"></i
                      ><span> far fa-calendar-plus</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-calendar-times"></i
                      ><span> far fa-calendar-times</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-caret-square-down"></i
                      ><span> far fa-caret-square-down</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-caret-square-left"></i
                      ><span> far fa-caret-square-left</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-caret-square-right"></i
                      ><span> far fa-caret-square-right</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-caret-square-up"></i
                      ><span> far fa-caret-square-up</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-chart-bar"></i
                      ><span> far fa-chart-bar</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-check-circle"></i
                      ><span> far fa-check-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-check-square"></i
                      ><span> far fa-check-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-circle"></i><span> far fa-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-clipboard"></i
                      ><span> far fa-clipboard</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-clock"></i><span> far fa-clock</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-clone"></i><span> far fa-clone</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-closed-captioning"></i
                      ><span> far fa-closed-captioning</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-comment"></i><span> far fa-comment</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-comment-alt"></i
                      ><span> far fa-comment-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-comments"></i
                      ><span> far fa-comments</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-compass"></i><span> far fa-compass</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-copy"></i><span> far fa-copy</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-copyright"></i
                      ><span> far fa-copyright</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-credit-card"></i
                      ><span> far fa-credit-card</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-dot-circle"></i
                      ><span> far fa-dot-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-edit"></i><span> far fa-edit</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-envelope"></i
                      ><span> far fa-envelope</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-envelope-open"></i
                      ><span> far fa-envelope-open</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-eye-slash"></i
                      ><span> far fa-eye-slash</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file"></i><span> far fa-file</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-alt"></i
                      ><span> far fa-file-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-archive"></i
                      ><span> far fa-file-archive</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-audio"></i
                      ><span> far fa-file-audio</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-code"></i
                      ><span> far fa-file-code</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-excel"></i
                      ><span> far fa-file-excel</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-image"></i
                      ><span> far fa-file-image</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-pdf"></i
                      ><span> far fa-file-pdf</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-powerpoint"></i
                      ><span> far fa-file-powerpoint</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-video"></i
                      ><span> far fa-file-video</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-file-word"></i
                      ><span> far fa-file-word</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-flag"></i><span> far fa-flag</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-folder"></i><span> far fa-folder</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-folder-open"></i
                      ><span> far fa-folder-open</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-frown"></i><span> far fa-frown</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-futbol"></i><span> far fa-futbol</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-gem"></i><span> far fa-gem</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-lizard"></i
                      ><span> far fa-hand-lizard</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-paper"></i
                      ><span> far fa-hand-paper</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-peace"></i
                      ><span> far fa-hand-peace</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-point-down"></i
                      ><span> far fa-hand-point-down</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-point-left"></i
                      ><span> far fa-hand-point-left</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-point-right"></i
                      ><span> far fa-hand-point-right</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-point-up"></i
                      ><span> far fa-hand-point-up</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-pointer"></i
                      ><span> far fa-hand-pointer</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-rock"></i
                      ><span> far fa-hand-rock</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-scissors"></i
                      ><span> far fa-hand-scissors</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hand-spock"></i
                      ><span> far fa-hand-spock</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-handshake"></i
                      ><span> far fa-handshake</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hdd"></i><span> far fa-hdd</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-heart"></i><span> far fa-heart</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hospital"></i
                      ><span> far fa-hospital</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-hourglass"></i
                      ><span> far fa-hourglass</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-id-badge"></i
                      ><span> far fa-id-badge</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-id-card"></i><span> far fa-id-card</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-image"></i><span> far fa-image</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-images"></i><span> far fa-images</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-keyboard"></i
                      ><span> far fa-keyboard</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-lemon"></i><span> far fa-lemon</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-life-ring"></i
                      ><span> far fa-life-ring</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-lightbulb"></i
                      ><span> far fa-lightbulb</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-list-alt"></i
                      ><span> far fa-list-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-map"></i><span> far fa-map</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-meh"></i><span> far fa-meh</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-minus-square"></i
                      ><span> far fa-minus-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-money-bill-alt"></i
                      ><span> far fa-money-bill-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-moon"></i><span> far fa-moon</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-newspaper"></i
                      ><span> far fa-newspaper</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-object-group"></i
                      ><span> far fa-object-group</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-object-ungroup"></i
                      ><span> far fa-object-ungroup</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-paper-plane"></i
                      ><span> far fa-paper-plane</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-pause-circle"></i
                      ><span> far fa-pause-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-play-circle"></i
                      ><span> far fa-play-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-plus-square"></i
                      ><span> far fa-plus-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-question-circle"></i
                      ><span> far fa-question-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-registered"></i
                      ><span> far fa-registered</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-save"></i><span> far fa-save</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-share-square"></i
                      ><span> far fa-share-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-smile"></i><span> far fa-smile</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-snowflake"></i
                      ><span> far fa-snowflake</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-square"></i><span> far fa-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-star"></i><span> far fa-star</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-star-half"></i
                      ><span> far fa-star-half</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-sticky-note"></i
                      ><span> far fa-sticky-note</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-stop-circle"></i
                      ><span> far fa-stop-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-sun"></i><span> far fa-sun</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-thumbs-down"></i
                      ><span> far fa-thumbs-down</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-thumbs-up"></i
                      ><span> far fa-thumbs-up</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-times-circle"></i
                      ><span> far fa-times-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-trash-alt"></i
                      ><span> far fa-trash-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-user"></i><span> far fa-user</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-user-circle"></i
                      ><span> far fa-user-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-window-close"></i
                      ><span> far fa-window-close</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-window-maximize"></i
                      ><span> far fa-window-maximize</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-window-minimize"></i
                      ><span> far fa-window-minimize</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="far fa-window-restore"></i
                      ><span> far fa-window-restore</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Brand Icons</h4>
                  <h6 class="card-subtitle">
                    use the icon by just put class
                    <code>fab fa-accessible-icon</code> in i tag
                  </h6>
                  <div class="clearfix icon-list-demo row">
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-500px"></i><span> fab fa-500px</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-accessible-icon"></i
                      ><span> fab fa-accessible-icon</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-accusoft"></i
                      ><span> fab fa-accusoft</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-adn"></i><span> fab fa-adn</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-adversal"></i
                      ><span> fab fa-adversal</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-affiliatetheme"></i
                      ><span> fab fa-affiliatetheme</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-algolia"></i><span> fab fa-algolia</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-amazon"></i><span> fab fa-amazon</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-amazon-pay"></i
                      ><span> fab fa-amazon-pay</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-amilia"></i><span> fab fa-amilia</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-android"></i><span> fab fa-android</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-angellist"></i
                      ><span> fab fa-angellist</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-angrycreative"></i
                      ><span> fab fa-angrycreative</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-angular"></i><span> fab fa-angular</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-app-store"></i
                      ><span> fab fa-app-store</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-app-store-ios"></i
                      ><span> fab fa-app-store-ios</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-apper"></i><span> fab fa-apper</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-apple"></i><span> fab fa-apple</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-apple-pay"></i
                      ><span> fab fa-apple-pay</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-asymmetrik"></i
                      ><span> fab fa-asymmetrik</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-audible"></i><span> fab fa-audible</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-autoprefixer"></i
                      ><span> fab fa-autoprefixer</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-avianex"></i><span> fab fa-avianex</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-aviato"></i><span> fab fa-aviato</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-aws"></i><span> fab fa-aws</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bandcamp"></i
                      ><span> fab fa-bandcamp</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-behance"></i><span> fab fa-behance</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-behance-square"></i
                      ><span> fab fa-behance-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bimobject"></i
                      ><span> fab fa-bimobject</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bitbucket"></i
                      ><span> fab fa-bitbucket</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bitcoin"></i><span> fab fa-bitcoin</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bity"></i><span> fab fa-bity</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-black-tie"></i
                      ><span> fab fa-black-tie</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-blackberry"></i
                      ><span> fab fa-blackberry</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-blogger"></i><span> fab fa-blogger</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-blogger-b"></i
                      ><span> fab fa-blogger-b</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bluetooth"></i
                      ><span> fab fa-bluetooth</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-bluetooth-b"></i
                      ><span> fab fa-bluetooth-b</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-btc"></i><span> fab fa-btc</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-buromobelexperte"></i
                      ><span> fab fa-buromobelexperte</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-amazon-pay"></i
                      ><span> fab fa-cc-amazon-pay</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-amex"></i><span> fab fa-cc-amex</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-apple-pay"></i
                      ><span> fab fa-cc-apple-pay</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-diners-club"></i
                      ><span> fab fa-cc-diners-club</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-discover"></i
                      ><span> fab fa-cc-discover</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-jcb"></i><span> fab fa-cc-jcb</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-mastercard"></i
                      ><span> fab fa-cc-mastercard</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-paypal"></i
                      ><span> fab fa-cc-paypal</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-stripe"></i
                      ><span> fab fa-cc-stripe</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cc-visa"></i><span> fab fa-cc-visa</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-centercode"></i
                      ><span> fab fa-centercode</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-chrome"></i><span> fab fa-chrome</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cloudscale"></i
                      ><span> fab fa-cloudscale</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cloudsmith"></i
                      ><span> fab fa-cloudsmith</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cloudversify"></i
                      ><span> fab fa-cloudversify</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-codepen"></i><span> fab fa-codepen</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-codiepie"></i
                      ><span> fab fa-codiepie</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-connectdevelop"></i
                      ><span> fab fa-connectdevelop</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-contao"></i><span> fab fa-contao</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cpanel"></i><span> fab fa-cpanel</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-creative-commons"></i
                      ><span> fab fa-creative-commons</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-css3"></i><span> fab fa-css3</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-css3-alt"></i
                      ><span> fab fa-css3-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-cuttlefish"></i
                      ><span> fab fa-cuttlefish</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-d-and-d"></i><span> fab fa-d-and-d</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-dashcube"></i
                      ><span> fab fa-dashcube</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-delicious"></i
                      ><span> fab fa-delicious</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-deploydog"></i
                      ><span> fab fa-deploydog</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-deskpro"></i><span> fab fa-deskpro</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-deviantart"></i
                      ><span> fab fa-deviantart</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-digg"></i><span> fab fa-digg</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-digital-ocean"></i
                      ><span> fab fa-digital-ocean</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-discord"></i><span> fab fa-discord</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-discourse"></i
                      ><span> fab fa-discourse</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-dochub"></i><span> fab fa-dochub</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-docker"></i><span> fab fa-docker</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-draft2digital"></i
                      ><span> fab fa-draft2digital</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-dribbble"></i
                      ><span> fab fa-dribbble</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-dribbble-square"></i
                      ><span> fab fa-dribbble-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-dropbox"></i><span> fab fa-dropbox</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-drupal"></i><span> fab fa-drupal</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-dyalog"></i><span> fab fa-dyalog</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-earlybirds"></i
                      ><span> fab fa-earlybirds</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-edge"></i><span> fab fa-edge</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-elementor"></i
                      ><span> fab fa-elementor</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-ember"></i><span> fab fa-ember</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-empire"></i><span> fab fa-empire</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-envira"></i><span> fab fa-envira</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-erlang"></i><span> fab fa-erlang</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-ethereum"></i
                      ><span> fab fa-ethereum</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-etsy"></i><span> fab fa-etsy</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-expeditedssl"></i
                      ><span> fab fa-expeditedssl</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-facebook"></i
                      ><span> fab fa-facebook</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-facebook-f"></i
                      ><span> fab fa-facebook-f</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-facebook-messenger"></i
                      ><span> fab fa-facebook-messenger</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-facebook-square"></i
                      ><span> fab fa-facebook-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-firefox"></i><span> fab fa-firefox</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-first-order"></i
                      ><span> fab fa-first-order</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-firstdraft"></i
                      ><span> fab fa-firstdraft</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-flickr"></i><span> fab fa-flickr</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-flipboard"></i
                      ><span> fab fa-flipboard</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-fly"></i><span> fab fa-fly</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-font-awesome"></i
                      ><span> fab fa-font-awesome</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-font-awesome-alt"></i
                      ><span> fab fa-font-awesome-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-font-awesome-flag"></i
                      ><span> fab fa-font-awesome-flag</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-fonticons"></i
                      ><span> fab fa-fonticons</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-fonticons-fi"></i
                      ><span> fab fa-fonticons-fi</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-fort-awesome"></i
                      ><span> fab fa-fort-awesome</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-fort-awesome-alt"></i
                      ><span> fab fa-fort-awesome-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-forumbee"></i
                      ><span> fab fa-forumbee</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-foursquare"></i
                      ><span> fab fa-foursquare</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-free-code-camp"></i
                      ><span> fab fa-free-code-camp</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-freebsd"></i><span> fab fa-freebsd</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-get-pocket"></i
                      ><span> fab fa-get-pocket</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gg"></i><span> fab fa-gg</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gg-circle"></i
                      ><span> fab fa-gg-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-git"></i><span> fab fa-git</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-git-square"></i
                      ><span> fab fa-git-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-github"></i><span> fab fa-github</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-github-alt"></i
                      ><span> fab fa-github-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-github-square"></i
                      ><span> fab fa-github-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gitkraken"></i
                      ><span> fab fa-gitkraken</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gitlab"></i><span> fab fa-gitlab</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gitter"></i><span> fab fa-gitter</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-glide"></i><span> fab fa-glide</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-glide-g"></i><span> fab fa-glide-g</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gofore"></i><span> fab fa-gofore</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-goodreads"></i
                      ><span> fab fa-goodreads</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-goodreads-g"></i
                      ><span> fab fa-goodreads-g</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google"></i><span> fab fa-google</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google-drive"></i
                      ><span> fab fa-google-drive</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google-play"></i
                      ><span> fab fa-google-play</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google-plus"></i
                      ><span> fab fa-google-plus</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google-plus-g"></i
                      ><span> fab fa-google-plus-g</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google-plus-square"></i
                      ><span> fab fa-google-plus-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-google-wallet"></i
                      ><span> fab fa-google-wallet</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gratipay"></i
                      ><span> fab fa-gratipay</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-grav"></i><span> fab fa-grav</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gripfire"></i
                      ><span> fab fa-gripfire</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-grunt"></i><span> fab fa-grunt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-gulp"></i><span> fab fa-gulp</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hacker-news"></i
                      ><span> fab fa-hacker-news</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hacker-news-square"></i
                      ><span> fab fa-hacker-news-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hips"></i><span> fab fa-hips</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hire-a-helper"></i
                      ><span> fab fa-hire-a-helper</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hooli"></i><span> fab fa-hooli</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hotjar"></i><span> fab fa-hotjar</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-houzz"></i><span> fab fa-houzz</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-html5"></i><span> fab fa-html5</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-hubspot"></i><span> fab fa-hubspot</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-imdb"></i><span> fab fa-imdb</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-instagram"></i
                      ><span> fab fa-instagram</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-internet-explorer"></i
                      ><span> fab fa-internet-explorer</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-ioxhost"></i><span> fab fa-ioxhost</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-itunes"></i><span> fab fa-itunes</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-itunes-note"></i
                      ><span> fab fa-itunes-note</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-jenkins"></i><span> fab fa-jenkins</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-joget"></i><span> fab fa-joget</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-joomla"></i><span> fab fa-joomla</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-js"></i><span> fab fa-js</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-js-square"></i
                      ><span> fab fa-js-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-jsfiddle"></i
                      ><span> fab fa-jsfiddle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-keycdn"></i><span> fab fa-keycdn</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-kickstarter"></i
                      ><span> fab fa-kickstarter</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-kickstarter-k"></i
                      ><span> fab fa-kickstarter-k</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-korvue"></i><span> fab fa-korvue</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-laravel"></i><span> fab fa-laravel</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-lastfm"></i><span> fab fa-lastfm</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-lastfm-square"></i
                      ><span> fab fa-lastfm-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-leanpub"></i><span> fab fa-leanpub</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-less"></i><span> fab fa-less</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-line"></i><span> fab fa-line</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-linkedin"></i
                      ><span> fab fa-linkedin</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-linkedin-in"></i
                      ><span> fab fa-linkedin-in</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-linode"></i><span> fab fa-linode</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-linux"></i><span> fab fa-linux</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-lyft"></i><span> fab fa-lyft</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-magento"></i><span> fab fa-magento</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-maxcdn"></i><span> fab fa-maxcdn</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-medapps"></i><span> fab fa-medapps</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-medium"></i><span> fab fa-medium</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-medium-m"></i
                      ><span> fab fa-medium-m</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-medrt"></i><span> fab fa-medrt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-meetup"></i><span> fab fa-meetup</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-microsoft"></i
                      ><span> fab fa-microsoft</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-mix"></i><span> fab fa-mix</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-mixcloud"></i
                      ><span> fab fa-mixcloud</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-mizuni"></i><span> fab fa-mizuni</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-modx"></i><span> fab fa-modx</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-monero"></i><span> fab fa-monero</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-napster"></i><span> fab fa-napster</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-nintendo-switch"></i
                      ><span> fab fa-nintendo-switch</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-node"></i><span> fab fa-node</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-node-js"></i><span> fab fa-node-js</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-npm"></i><span> fab fa-npm</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-ns8"></i><span> fab fa-ns8</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-nutritionix"></i
                      ><span> fab fa-nutritionix</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-odnoklassniki"></i
                      ><span> fab fa-odnoklassniki</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-odnoklassniki-square"></i
                      ><span> fab fa-odnoklassniki-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-opencart"></i
                      ><span> fab fa-opencart</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-openid"></i><span> fab fa-openid</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-opera"></i><span> fab fa-opera</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-optin-monster"></i
                      ><span> fab fa-optin-monster</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-osi"></i><span> fab fa-osi</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-page4"></i><span> fab fa-page4</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pagelines"></i
                      ><span> fab fa-pagelines</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-palfed"></i><span> fab fa-palfed</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-patreon"></i><span> fab fa-patreon</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-paypal"></i><span> fab fa-paypal</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-periscope"></i
                      ><span> fab fa-periscope</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-phabricator"></i
                      ><span> fab fa-phabricator</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-phoenix-framework"></i
                      ><span> fab fa-phoenix-framework</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-php"></i><span> fab fa-php</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pied-piper"></i
                      ><span> fab fa-pied-piper</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pied-piper-alt"></i
                      ><span> fab fa-pied-piper-alt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pied-piper-pp"></i
                      ><span> fab fa-pied-piper-pp</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pinterest"></i
                      ><span> fab fa-pinterest</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pinterest-p"></i
                      ><span> fab fa-pinterest-p</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pinterest-square"></i
                      ><span> fab fa-pinterest-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-playstation"></i
                      ><span> fab fa-playstation</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-product-hunt"></i
                      ><span> fab fa-product-hunt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-pushed"></i><span> fab fa-pushed</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-python"></i><span> fab fa-python</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-qq"></i><span> fab fa-qq</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-quinscape"></i
                      ><span> fab fa-quinscape</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-quora"></i><span> fab fa-quora</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-ravelry"></i><span> fab fa-ravelry</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-react"></i><span> fab fa-react</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-readme"></i><span> fab fa-readme</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-rebel"></i><span> fab fa-rebel</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-red-river"></i
                      ><span> fab fa-red-river</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-reddit"></i><span> fab fa-reddit</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-reddit-alien"></i
                      ><span> fab fa-reddit-alien</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-reddit-square"></i
                      ><span> fab fa-reddit-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-rendact"></i><span> fab fa-rendact</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-renren"></i><span> fab fa-renren</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-replyd"></i><span> fab fa-replyd</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-resolving"></i
                      ><span> fab fa-resolving</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-rocketchat"></i
                      ><span> fab fa-rocketchat</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-rockrms"></i><span> fab fa-rockrms</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-safari"></i><span> fab fa-safari</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-sass"></i><span> fab fa-sass</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-schlix"></i><span> fab fa-schlix</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-scribd"></i><span> fab fa-scribd</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-searchengin"></i
                      ><span> fab fa-searchengin</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-sellcast"></i
                      ><span> fab fa-sellcast</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-sellsy"></i><span> fab fa-sellsy</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-servicestack"></i
                      ><span> fab fa-servicestack</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-shirtsinbulk"></i
                      ><span> fab fa-shirtsinbulk</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-simplybuilt"></i
                      ><span> fab fa-simplybuilt</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-sistrix"></i><span> fab fa-sistrix</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-skyatlas"></i
                      ><span> fab fa-skyatlas</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-skype"></i><span> fab fa-skype</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-slack"></i><span> fab fa-slack</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-slack-hash"></i
                      ><span> fab fa-slack-hash</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-slideshare"></i
                      ><span> fab fa-slideshare</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-snapchat"></i
                      ><span> fab fa-snapchat</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-snapchat-ghost"></i
                      ><span> fab fa-snapchat-ghost</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-snapchat-square"></i
                      ><span> fab fa-snapchat-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-soundcloud"></i
                      ><span> fab fa-soundcloud</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-speakap"></i><span> fab fa-speakap</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-spotify"></i><span> fab fa-spotify</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-stack-exchange"></i
                      ><span> fab fa-stack-exchange</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-stack-overflow"></i
                      ><span> fab fa-stack-overflow</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-staylinked"></i
                      ><span> fab fa-staylinked</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-steam"></i><span> fab fa-steam</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-steam-square"></i
                      ><span> fab fa-steam-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-steam-symbol"></i
                      ><span> fab fa-steam-symbol</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-sticker-mule"></i
                      ><span> fab fa-sticker-mule</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-strava"></i><span> fab fa-strava</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-stripe"></i><span> fab fa-stripe</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-stripe-s"></i
                      ><span> fab fa-stripe-s</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-studiovinari"></i
                      ><span> fab fa-studiovinari</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-stumbleupon"></i
                      ><span> fab fa-stumbleupon</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-stumbleupon-circle"></i
                      ><span> fab fa-stumbleupon-circle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-superpowers"></i
                      ><span> fab fa-superpowers</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-supple"></i><span> fab fa-supple</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-telegram"></i
                      ><span> fab fa-telegram</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-telegram-plane"></i
                      ><span> fab fa-telegram-plane</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-tencent-weibo"></i
                      ><span> fab fa-tencent-weibo</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-themeisle"></i
                      ><span> fab fa-themeisle</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-trello"></i><span> fab fa-trello</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-tripadvisor"></i
                      ><span> fab fa-tripadvisor</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-tumblr"></i><span> fab fa-tumblr</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-tumblr-square"></i
                      ><span> fab fa-tumblr-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-twitch"></i><span> fab fa-twitch</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-twitter"></i><span> fab fa-twitter</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-twitter-square"></i
                      ><span> fab fa-twitter-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-typo3"></i><span> fab fa-typo3</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-uber"></i><span> fab fa-uber</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-uikit"></i><span> fab fa-uikit</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-uniregistry"></i
                      ><span> fab fa-uniregistry</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-untappd"></i><span> fab fa-untappd</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-usb"></i><span> fab fa-usb</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-ussunnah"></i
                      ><span> fab fa-ussunnah</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vaadin"></i><span> fab fa-vaadin</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-viacoin"></i><span> fab fa-viacoin</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-viadeo"></i><span> fab fa-viadeo</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-viber"></i><span> fab fa-viber</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vimeo"></i><span> fab fa-vimeo</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vimeo-square"></i
                      ><span> fab fa-vimeo-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vimeo-v"></i><span> fab fa-vimeo-v</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vine"></i><span> fab fa-vine</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vk"></i><span> fab fa-vk</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vnv"></i><span> fab fa-vnv</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-vuejs"></i><span> fab fa-vuejs</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-weibo"></i><span> fab fa-weibo</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-weixin"></i><span> fab fa-weixin</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-whatsapp"></i
                      ><span> fab fa-whatsapp</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-whatsapp-square"></i
                      ><span> fab fa-whatsapp-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-whmcs"></i><span> fab fa-whmcs</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-wikipedia-w"></i
                      ><span> fab fa-wikipedia-w</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-windows"></i><span> fab fa-windows</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-wordpress"></i
                      ><span> fab fa-wordpress</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-wordpress-simple"></i
                      ><span> fab fa-wordpress-simple</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-wpbeginner"></i
                      ><span> fab fa-wpbeginner</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-wpexplorer"></i
                      ><span> fab fa-wpexplorer</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-wpforms"></i><span> fab fa-wpforms</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-xbox"></i><span> fab fa-xbox</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-xing"></i><span> fab fa-xing</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-xing-square"></i
                      ><span> fab fa-xing-square</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-y-combinator"></i
                      ><span> fab fa-y-combinator</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-yahoo"></i><span> fab fa-yahoo</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-yandex"></i><span> fab fa-yandex</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-yandex-international"></i
                      ><span> fab fa-yandex-international</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-yelp"></i><span> fab fa-yelp</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-yoast"></i><span> fab fa-yoast</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-youtube"></i><span> fab fa-youtube</span>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-3 f-icon">
                      <i class="fab fa-youtube-square"></i
                      ><span> fab fa-youtube-square</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- ============================================================== -->
          <!-- End PAge Content -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- Right sidebar -->
          <!-- ============================================================== -->
          <!-- .right-sidebar -->
          <!-- ============================================================== -->
          <!-- End Right sidebar -->
          <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer text-center">
          All Rights Reserved by Matrix-admin. Designed and Developed by
          <a href="https://www.wrappixel.com">WrapPixel</a>.
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
      </div>
      <!-- ============================================================== -->
      <!-- End Page wrapper  -->
      <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
  </body>
</html>
