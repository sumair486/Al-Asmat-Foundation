<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company_infos extends Model
{
    protected $table = 'company_infos';
    protected $guarded = [];

}
